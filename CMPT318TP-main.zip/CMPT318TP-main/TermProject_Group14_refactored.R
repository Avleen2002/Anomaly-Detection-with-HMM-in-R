# Group Assignment 3 - CMPT 318
# Author: Group 14
# Date: 25 March, 2024

# Installing necessary packages
#install.packages(c("depmixS4", "ggplot2", "dplyr", "ggbiplot", "stats", "lubridate", "gplots"))

# Activating necessary packages
library(depmixS4)
library(dplyr)
library(ggbiplot)
library(stats)
library(lubridate)
library(gplots)

# Clearing Previous Environment and Set Working Directory
rm(list = ls()) 
setwd("~/CMPT318/CMPT318TP")

######################################################################################################################################################
## Functions ##
######################################################################################################################################################

interpolate_data <- function(dataset){
  
  for (i in 3:length(colnames(dataset))) {
    na_indices <- which(is.na(dataset[[i]])) # Get the indices of each NA entry
    not_na_indices <- which(!is.na(dataset[[i]])) # Get indices of non-NA entries
    dataset[[i]][na_indices] <- approx(x=not_na_indices, 
                                       y=dataset[[i]][not_na_indices],
                                       xout=na_indices)$y # get the interpolated y-value of each NA point
  }
  
  dataset$Datetime <- as.POSIXct(paste(dataset$Date, dataset$Time), format = "%d/%m/%Y %H:%M:%S")
  return(dataset)
}

#Contains time window used
filter_time_window <- function(data) {
  
  day_str <- "Wednesday"
  start_time_hr <- 16   # 4:00 PM
  end_time_hr <- 19     # 7:00 PM
  
  data <- data %>%
    filter(weekdays(Datetime) == day_str,
           hour(Datetime) >= start_time_hr,
           hour(Datetime) < end_time_hr)
  
  return(data)
}

get_time_lens <- function(data_window){
  
  time_lens <- c()
  count <- 1 # initialize count to 1
  for (i in 2:nrow(data_window)) { # loop through the feature, starting at 2
    # if the next time is larger than the previous, increment count
    if (as.numeric(format(data_window$Datetime[i], "%H%M%S")) > as.numeric(format(data_window$Datetime[i-1], "%H%M%S"))) {
      count <- count + 1
    } else {
      # time window reset, save the time length and reset count
      time_lens <- c(time_lens, count)
      count <- 1
    }
  }
  time_lens <- c(time_lens, count)
  return(time_lens)
}
  
get_pca_result <- function(data_test_window, data_train_window){
  
  data_all_windows <- rbind(data_train_window, data_test_window)
  pca_result <- prcomp(data_all_windows[, 3:9], scale. = TRUE)
  loadings <- pca_result$rotation 
  for (i in 1:ncol(loadings)) {
    loadings_PC <- loadings[, i]  # Loadings for current principal component
    correlation_PC <- abs(loadings_PC)  # Take absolute values for easier interpretation
    correlation_PC_sorted <- sort(correlation_PC, decreasing = TRUE)  # Sort by magnitude
    cat("Principal Component", i, "is strongly correlated with:\n")
    cat(names(correlation_PC_sorted)[1:3], "\n")  # Print top 3 strongly correlated variables
    cat("\n")
  }
  blue_palette <- colorRampPalette(c("lightblue", "blue"))(100)
  
  # Generate the heatmap with heatmap.2
  heatmap.2(t(abs(loadings)),
            col = blue_palette,
            Rowv = FALSE,
            Colv = FALSE,
            scale = "none",
            keysize = 1,    
            symkey = FALSE,           
            density.info = "none",    
            trace = "none",
            dendrogram = "none",
            srtCol  = 45,
            margins = c(10, 10)         # Adjust margins
  )
  print(ggscreeplot(pca_result))
  groups_vector <- factor(c(rep("Train", nrow(data_train_window)),
                            rep("Test", nrow(data_test_window))))
  
  # Generate the biplot
  p <- ggbiplot(pca_result, groups = groups_vector, ellipse = TRUE, circle = TRUE)
  print(p)
  
  return(pca_result)
}

get_loadings_means <- function(loadings){
  
  means <- c("Global_active_power"=0, "Global_reactive_power"=0, "Voltage"=0, "Global_intensity"=0, "Sub_metering_1"=0, "Sub_metering_2"=0, "Sub_metering_3"=0)
  for (i in 1:4) {
    for (j in 1:7) {
      means[j] = means[j] + abs(loadings[j,i+1])
    }
    means[j] = means[j] / 4
  }
  
  print(sort(means, decreasing = TRUE))
  
  return(means)
}

# Function to find the best HMM model
find_best_hmm_model <- function(data, time_lens) {
  best_model <- NULL
  best_bic <- Inf
  best_logLik <- -Inf
  min_states <- 4
  max_states <- 14
  
  res <- list()
  family_list <- list(gaussian("identity"), gaussian("identity"))
  for (i in seq_along(features)) {
    resp_as_formula <- formula(paste(features[i], "~ 1", collapse = " "))
    res <- append(res, resp_as_formula, after=i)
  }
  
  fitted_models <- c()
  
  set.seed(1)
  for (num_states in min_states:max_states) {
    # Fit the HMM model with 'num_states' states
    model <- depmix(response = res, data=data, nstates=num_states,
                    family = family_list,
                    ntimes = time_lens)
    fitted_model <- fit(model)
    fitted_models <- c(fitted_models, fitted_model)
    # Calculate BIC and logLikelihood
    bic_value <- BIC(fitted_model)
    logLik_value <- logLik(fitted_model)
    
    # Check if this model has the best BIC so far
    if (bic_value < best_bic || (bic_value == best_bic && logLik_value > best_logLik)) {
      best_bic <- bic_value
      best_logLik <- logLik_value
      best_model <- fitted_model
    }
  }
  
  bic_vals <- sapply(fitted_models, BIC)
  logLik_vals <- sapply(fitted_models, logLik)
  
  print(length(fitted_models))
  print(length(bic_vals))
  
  plot(seq(min_states, min_states + length(fitted_models) - 1), bic_vals, type="b", xlab="Model Fit Number", ylab="BIC Value")
  plot(seq(min_states, min_states + length(fitted_models) - 1), logLik_vals, type="b", xlab="Model Fit Number", ylab="Log Likelihood Value")
  
  
  return(list(best_model = best_model, best_bic = best_bic, best_logLik = best_logLik))
}

test_model <- function(model, data_window, time_lens){
  
  res <- list()
  family_list <- list(gaussian("identity"), gaussian("identity"))
  for (i in seq_along(features)) {
    resp_as_formula <- formula(paste(features[i], "~ 1", collapse = " "))
    res <- append(res, resp_as_formula, after=i)
  }
  
  mtest <- depmix(response = res, data=data_window, nstates=model@nstates,
                  family = family_list,
                  ntimes = time_lens)
  
  mtest <- setpars(mtest, getpars(model))
  
  return(mtest)
}

######################################################################################################################################################
## Main Code ##
######################################################################################################################################################

# Reading the dataset

dataset <- read.csv("household_power_consumption.txt", na.strings = "?", sep = ";") 

######################################### PREPROCESSING
# Preprocess data (remove '?' values with linear interpolation) and add datetime column

dataset <- interpolate_data(dataset)

######################################### PARTITION DATA 


starting_index_test <- nrow(dataset) - 60*24*7*56 + 1
starting_index_train <- 1

data_train <- dataset[starting_index_train:starting_index_test-1,]
data_test <- dataset[starting_index_test:nrow(dataset),]

# Scale data (independently)
scaled_train <- scale(data_train[3:9])
scaled_test <- scale(data_test[3:9])

# Assign scaled features
data_train[, 3:9] <- scaled_train
data_test[, 3:9] <- scaled_test

# Filtering to time window chosen
data_train_window <- filter_time_window(data_train)

# Filtering to time window chosen
data_test_window <- filter_time_window(data_test)

# Getting the time window lengths for test and train to feed into HMM
time_lens_train <- get_time_lens(data_train_window)

time_lens_test <- get_time_lens(data_test_window)

######################################### PRINCIPAL COMPONENT ANALYSIS (SECTION 2)
pca_result <- get_pca_result(data_test_window, data_train_window)

loadings <- pca_result$rotation


features <- c('Global_active_power') # As it is the feature with the highest correlation to PC1

means <- get_loadings_means(loadings)
features <- c(features, names(sort(means, decreasing = TRUE)[2])) # Using 2nd index which is 'Voltage as it has a comparably high average score and an better distribution for the HMM'

print(features);
######################################### TRAIN HMM (SECTION 3 - Cont.)

set.seed(1)
#Train model
mtrain <- find_best_hmm_model(data_train_window, time_lens_train)[1]$best_model

# Test model
mtest <- test_model(mtrain,data_test_window,time_lens_test)

loglik_train <- forwardbackward(mtrain)$logLike
loglik_test <- forwardbackward(mtest)$logLike

# Normalize loglikelihood
normalized_loglik_train <- loglik_train / nrow(data_train_window)
normalized_loglik_test <- loglik_test / nrow(data_test_window)

print(normalized_loglik_train)
print(normalized_loglik_test)
print(normalized_loglik_test / normalized_loglik_train)

######################################### ANOMALY DETECTION
# seperate rows by breaking into 10 sets of indices 1..10
test_subsets_indices <- cut(seq(1, length(time_lens_test)), breaks = 10, labels = FALSE)
test_subsets_loglik <- list()

# use the unique indices to form actual subsets
test_cpy <- data_test_window
for (i in seq_along(unique(test_subsets_indices))) {
  test_sub_len <- time_lens_test[test_subsets_indices == i]
  test_subset <- head(test_cpy, sum(test_sub_len))
  test_cpy <- tail(test_cpy, nrow(test_cpy)-sum(test_sub_len))
  
  mtest_i <- test_model(mtrain, test_subset, test_sub_len)
  
  test_subsets_loglik <- c(test_subsets_loglik, forwardbackward(mtest_i)$logLike)
}

# normalize each loglik subset
normalized_loglik_sub <- c()
for (i in seq_along(test_subsets_loglik)) {
  normalized_loglik_sub <- c(normalized_loglik_sub, test_subsets_loglik[[i]] / sum(time_lens_test[test_subsets_indices == i]))
  print(normalized_loglik_sub[i])
}

# Get max deviation
max_loglik_deviation <- max(abs(normalized_loglik_train - normalized_loglik_sub))
print(paste("Max loglike deviation (anomaly threshold): ", max_loglik_deviation))
