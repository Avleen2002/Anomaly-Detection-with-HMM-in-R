# Group Assignment 3 - CMPT 318
# Author: Group 14
# Date: 25 March, 2024

# Installing necessary packages
#install.packages(c("depmixS4", "ggplot2", "dplyr", "ggbiplot", "stats", "lubridate"))

# Activating necessary packages
library(depmixS4)
library(dplyr)
library(ggbiplot)
library(stats)
library(lubridate)

# Clearing Previous Environment
rm(list = ls()) 

# Reading the dataset
getwd()
setwd("~/CMPT318/PROJECT") # relative path
dataset <- read.csv("household_power_consumption.txt", na.strings = "?", sep = ";") 

######################################### PREPROCESSING
# Preprocess data (remove '?' values with linear interpolation)
for (i in 3:length(colnames(dataset))) {
  na_indices <- which(is.na(dataset[[i]])) # Get the indices of each NA entry
  not_na_indices <- which(!is.na(dataset[[i]])) # Get indices of non-NA entries
  dataset[[i]][na_indices] <- approx(x=not_na_indices, 
                                     y=dataset[[i]][not_na_indices],
                                     xout=na_indices)$y # get the interpolated y-value of each NA point
}


######################################### PARTITION DATA 
data <- dataset

data$Datetime <- as.POSIXct(paste(dataset$Date, dataset$Time), format = "%d/%m/%Y %H:%M:%S")

starting_index_test <- nrow(data) - 60*24*7*56 + 1
starting_index_train <- 1

data_train <- data[starting_index_train:starting_index_test-1,]
data_test <- data[starting_index_test:nrow(data),]

# Scale data (independently)
scaled_train <- scale(data_train[3:9])
scaled_test <- scale(data_test[3:9])

# Assign scaled features
data_train[, 3:9] <- scaled_train
data_test[, 3:9] <- scaled_test

# Get the time window data

day_str <- "Wednesday"
start_time_hr <- 16
end_time_hr <- 19

data_train_window <- data_train %>%
  filter(weekdays(Datetime) == day_str,
         hour(Datetime) >= start_time_hr,
         hour(Datetime) < end_time_hr)

data_test_window <- data_test %>%
  filter(weekdays(Datetime) == day_str,
         hour(Datetime) >= start_time_hr,
         hour(Datetime) < end_time_hr)


time_lens_train <- c()
count <- 1 # initialize count to 1
for (i in 2:nrow(data_train_window)) { # loop through the feature, starting at 2
  # if the next time is larger than the previous, increment count
  if (as.numeric(format(data_train_window$Datetime[i], "%H%M%S")) > as.numeric(format(data_train_window$Datetime[i-1], "%H%M%S"))) {
    count <- count + 1
  } else {
    # time window reset, save the time length and reset count
    time_lens_train <- c(time_lens_train, count)
    count <- 1
  }
}
time_lens_train <- c(time_lens_train, count)

time_lens_test <- c()
count <- 1 # initialize count to 1
for (i in 2:nrow(data_test_window)) { # loop through the feature, starting at 2
  # if the next time is larger than the previous, increment count
  if (as.numeric(format(data_test_window$Datetime[i], "%H%M%S")) > as.numeric(format(data_test_window$Datetime[i-1], "%H%M%S"))) {
    count <- count + 1
  } else {
    # time window reset, save the time length and reset count
    time_lens_test <- c(time_lens_test, count)
    count <- 1
  }
}
time_lens_test <- c(time_lens_test, count)

######################################### PRINCIPAL COMPONENT ANALYSIS (SECTION 2)
data_all_windows <- rbind(data_train_window, data_test_window)
pca_result <- prcomp(data_all_windows[, 3:9], scale. = TRUE)
loadings <- pca_result$rotation 
for (i in 1:ncol(loadings)) {
  loadings_PC <- loadings[, i]  # Loadings for current principal component
  correlation_PC <- abs(loadings_PC)  # Take absolute values for easier interpretation
  correlation_PC_sorted <- sort(correlation_PC, decreasing = TRUE)  # Sort by magnitude
  cat("Principal Component", i, "is strongly correlated with:\n")
  cat(names(correlation_PC_sorted)[1:3], "\n")  # Print top 3 strongly correlated variables
  cat("\n")
}
ggscreeplot(pca_result)

means <- c("Global_active_power"=0, "Global_reactive_power"=0, "Voltage"=0, "Global_intensity"=0, "Sub_metering_1"=0, "Sub_metering_2"=0, "Sub_metering_3"=0)
for (i in 1:4) {
  for (j in 1:7) {
    means[j] = means[j] + abs(loadings[j,i+1])
  }
  means[j] = means[j] / 4
}

print(sort(means, decreasing = TRUE))

features <- c('Global_active_power', 'Voltage')


######################################### TRAIN HMM (SECTION 3 - Cont.)
#states_lower_bound <- 4
#states_upper_bound <- 16

#fits_train <- c()

res <- list()
family_list <- list(gaussian("identity"), gaussian("identity"))
for (i in seq_along(features)) {
  resp_as_formula <- formula(paste(features[i], "~ 1", collapse = " "))
  res <- append(res, resp_as_formula, after=i)
}

# Loop through each state number to find optimal train result
#for (i in seq(states_lower_bound, states_upper_bound)) {
#  model_train <- depmix(response = response_train, data=data_train_window, nstates=i,
#                  family = family_list,
#                  ntimes=time_lens)
#  mfit_train <- fit(model_train, verbose = TRUE)
#  fits_train <- c(fits_train, mfit_train)
#}

#bic_vals_train <- sapply(fits_train, BIC)
#logLik_vals_train <- sapply(fits_train, logLik)
#plot(seq(states_lower_bound, states_lower_bound+length(fits_train)-1), bic_vals_train, type="b", xlab="Model Fit Number", ylab="BIC Value")
#plot(seq(states_lower_bound, states_lower_bound+length(fits_train)-1), logLik_vals_train, type="b", xlab="Model Fit Number", ylab="Log Likelihood Value")

set.seed(1)
#Train model
mtrain <- depmix(response = res, data=data_train_window, nstates=8,
                          family = family_list,
                          ntimes = time_lens_train)

# Test model
mtest <- depmix(response = res, data=data_test_window, nstates=8,
                family = family_list,
                ntimes = time_lens_test)

print(npar(mtrain))
print(npar(mtest))
print((npar(mtrain)-npar(mtest))/mtest@nstates)

# Train fit
mfit_train <- fit(mtrain, verbose = TRUE)

mtest <- setpars(mtest, getpars(mfit_train))

loglik_train <- forwardbackward(mfit_train)$logLike
loglik_test <- forwardbackward(mtest)$logLike

# Normalize loglikelihood
normalized_loglik_train <- loglik_train / nrow(data_train_window)
normalized_loglik_test <- loglik_test / nrow(data_test_window)

print(normalized_loglik_train)
print(normalized_loglik_test)
print(normalized_loglik_test / normalized_loglik_train)

######################################### ANOMALY DETECTION
# seperate rows by breaking into 10 sets of indices 1..10
test_subsets_indices <- cut(seq(1, length(time_lens_test)), breaks = 10, labels = FALSE)
test_subsets_loglik <- list()

# use the unique indices to form actual subsets
test_cpy <- data_test_window
for (i in seq_along(unique(test_subsets_indices))) {
  test_sub_len <- time_lens_test[test_subsets_indices == i]
  test_subset <- head(test_cpy, sum(test_sub_len))
  test_cpy <- tail(test_cpy, nrow(test_cpy)-sum(test_sub_len))
  
  mtest_i <- depmix(response = res, data=test_subset, nstates=8,
                  family = family_list,
                  ntimes = test_sub_len)
  
  setpars(mtest_i, getpars(mfit_train))
  
  test_subsets_loglik <- c(test_subsets_loglik, forwardbackward(mtest_i)$logLike)
}

# normalize each loglik subset
normalized_loglik_sub <- c()
for (i in seq_along(test_subsets_loglik)) {
  normalized_loglik_sub <- c(normalized_loglik_sub, test_subsets_loglik[[i]] / sum(time_lens_test[test_subsets_indices == i]))
  print(normalized_loglik_sub[i])
}

# Get max deviation
max_loglik_deviation <- max(abs(normalized_loglik_train - normalized_loglik_sub))
print(paste("Max loglike deviation: ", max_loglik_deviation))
